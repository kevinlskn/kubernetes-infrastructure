# Changelog

This file documents all notable changes to NDP Cache Server Helm Chart. The release numbering uses [semantic versioning](https://semver.org/).

## 1.14.0 - 2026/07/22

* Support BMS 1.14.0
* Bump chart version to align with BMS version
* Add tolerations support
* Add OpenShift support

## 1.1.0

* Support for NDP Cache Server v1.6.0
* Add support for OpenTelemetry

## 1.0.0

* Support for NDP Cache Server v1.5.0
