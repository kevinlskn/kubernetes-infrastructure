# Changelog

This file documents all notable changes to Paro Helm Chart. The release numbering uses [semantic versioning](https://semver.org/).

## 1.22.0

* Support for Paro v1.14.0

## 2026/03/05 - 1.21.0

* Support for Paro v1.13.0

## 1.20.0

* Support for Paro v1.12.0

## 1.16.0

* Support for Paro v1.8.0

## 1.15.2

* Support for Paro v1.7.1

## 1.15.1

* Fix incorrect configmap name of NEC Iris license file

## 1.15.0

* Support for Paro v1.7.0

## 1.14.0

* Support for Paro v1.6.0
* Add option for Multimodal Search API

## 1.13.0

* Support for Paro v1.5.1

## 1.12.2

* Fix deployment error due to incorrect mapping between configmap and values.yaml

## 1.12.1

* Fix `manager.workerKeepAlive.enabled` not working
* [BREAKING CHANGE] Change helm value name from `worker.extract.face.enableEyeDistanceAutoScaling` to `worker.extract.enableEyeDistanceAutoScaling`

## 1.12.0

* Support for Paro v1.5.0
* Add `worker.extract.face.enableEyeDistanceAutoScaling` to helm values
* [BREAKING CHANGE] Change helm value name from `manager.ndpCacheServerUri` to `manager.ndpCacheServerServiceDns`

## 1.11.0

* Support for Paro v1.4.14

## 1.10.0

* Support for Paro v1.4.13
* Add option for NEC Iris license

## 1.9.0

* Support for Paro v1.4.12
* Add ndp-cache-server integration and remove embedded hazelcast resources

## 1.8.1

* Restrict permission of role for paro manager

## 1.8.0

* Support for Paro v1.4.11
