{{- define "paro.namespace" -}}
  {{- if eq .Release.Namespace "default" -}}
    paro
  {{- else -}}
    {{- printf "%s" .Release.Namespace -}}
  {{- end -}}
{{- end -}}

{{/*
Detect whether the target cluster is OpenShift (has the security.openshift.io/v1 API).
OpenShift's SCC assigns runAsUser/runAsGroup/fsGroup automatically and rejects pods
that set them explicitly, so callers use this to skip those fields.
Returns "true" or "false" as a string; compare with eq/ne, not a direct if/not.
*/}}
{{- define "isOpenShift" -}}
{{- .Capabilities.APIVersions.Has "security.openshift.io/v1" -}}
{{- end -}}
