# Transaction Manager Helm Chart

![Version: 1.22.0](https://img.shields.io/badge/Version-1.22.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 1.14.0](https://img.shields.io/badge/AppVersion-1.14.0-informational?style=flat-square)

Helm chart for [Transaction Manager](https://dev.azure.com/necamdpf/DPFUS/_git/TxnMgr).

## Prerequisite

- Kubernetes: 1.26+
- Helm: 3
```sh
curl https://raw.githubusercontent.com/helm/helm/master/scripts/get-helm-3 > get_helm.sh
chmod 700 get_helm.sh
./get_helm.sh
```
- Postgres: 14

## Installation Postgres
### Database Configuration
Connect to database and create databases and users required for dependencies and Transaction Manager.
```sh
CREATE DATABASE txnmgr;
CREATE USER paro WITH PASSWORD 'pass';
GRANT ALL PRIVILEGES ON DATABASE txnmgr to paro;
```

##### Edit pg_hba.conf

The pg_hba.conf file controls the client authentication. Edit this file to allow
connections from all hosts. This file is usually located in the `pg_data` directory
(where PostgreSQL is installed).

If PostgreSQL has been installed on the host Ubuntu OS, edit
`/etc/postgresql/14/main/pg_hba.conf` and add an try to allow all interfaces.

```sh
host    all             all             0.0.0.0/0               scram-sha-256
```
##### Edit postgresql.conf file
The `postgresql.conf` file contains various configuration settings for the PostgreSQL
server. You need to ensure that it is set up to listen on all available IP addresses.

Find the line that starts with listen_addresses and set it to:

```sh
listen_addresses = '*'
```

##### Restart PostgreSQL
After making these changes, you need to restart the PostgreSQL server for the changes to take effect.
Once the server is restarted, you should be able to connect to it from any host.

### Transaction Manager Database
Transaction Manager requires MySQL, MSSQL and Postgres

Create the database txnmgr
Give the txnmgr.db.username configured in values.yaml full user rights to the database

### Log into repository
```sh
helm registry login parodev.azurecr.io -u <username>
Password:
```

### Install Dependent Components

Install Paro and dependent components before installing Transaction Manager.
Follow the installation instructions for installing the Paro Manager and
it's dependencies.

## Install Transaction Manager
- Transaction Manager
```sh
helm pull oci://parodev.azurecr.io/helm/paro/txnmgr --version x.y.z
```

Confirm the files have been pulled successfully by listing the `*.tgz` files

```sh
ls *.tgz
txnmgr-x.y.z.tgz
```
Extract the files required to install this product.

```sh
tar xvzf txnmgr-x.y.z.tgz
```
#### Edit Helm

##### Transaction Manager
```sh
vi txnmgr/values.yaml
```
| Parameters                                  | Default value                                                                                                           | Description                                                                         |
|---------------------------------------------|-------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------|
| image.registry                              | registry.example.com                                                                                                    | Update the private registry information with the one that image has been registered |
| imagePullSecret.registryCredential.username | username                                                                                                                | Specify the username of the private registry                                        |
| imagePullSecret.registryCredential.password | password                                                                                                                | Specify the password of the private registry                                        |
| txnmgr.enabled                              | true                                                                                                                    | Set to false if not using Transaction Manager                                       |
| txnmgr.db.jdbcUrl                           | jdbc:mariadb://mysql.example.com:3306/txnmgr?serverTimezone=UTC&allowPublicKeyRetrieval=true&socketTimeout=3000         | Update JDBC connection string                                                       |
| txnmgr.db.username                          | username                                                                                                                | Update the database username                                                        |
| txnmgr.db.password                          | password                                                                                                                | Update the database password                                                        |
| txnmgr.azure.blobStorage.endpoint           | https://txnmgr.blob.core.windows.net/                                                                                   | Azure Blob Storage endpoint URL                                                     |
| txnmgr.azure.blobStorage.containerName      | jobpayload                                                                                                              | Azure Blob storage container name                                                   |
| txnmgr.azure.blobStorage.sasToken           |                                                                                                                         | Azure Blob storage sasToken                                                         |

#### Run Helm Installation
```sh
helm install txnmgr txnmgr --namespace=paro --create-namespace
```

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| gateway.className | string | `"eg"` | Gateway class name (mandatory) eg=Envoy Gateway |
| gateway.enabled | bool | `false` | Create a gateway or not. |
| gateway.host | string | `"tm.example.com"` | FQDN of a network host. |
| gateway.path | string | `"/"` | Path of an incoming request. |
| gateway.pathType | string | `"PathPrefix"` | Type of the interpretation of the Path matching. |
| gateway.service.annotations | object | `{}` | Gateway service annotations. |
| gateway.service.type | string | `"ClusterIP"` | Gateway service type. (ClusterIP, LoadBalancer) |
| gateway.tls.secret | string | `"txnmgr-gateway-tls"` | Name of th secret used to terminate TLS traffic on Gateway. |
| image.registry | string | `"registry.example.com"` | Transaction manager container image registry. |
| image.txnmgr.pullPolicy | string | `"Always"` | Transaction manager pull policy. |
| image.txnmgr.repository | string | `"txnmgr"` | Transaction manager repository. |
| image.txnmgr.tag | string | `"1.14.0"` | Transaction manager tag. |
| image.txnmgrLiquibase.pullPolicy | string | `"Always"` | Transaction manager pull policy. |
| image.txnmgrLiquibase.repository | string | `"txnmgr-liquibase"` | Transaction manager repository. |
| image.txnmgrLiquibase.tag | string | `"1.14.0"` | Transaction manager tag. |
| imagePullSecret.name | string | `"txnmgr-regcred"` | Image pull secret name for pulling transaction manager container images. |
| imagePullSecret.registryCredential.password | string | `"password"` | Private container registry password for pulling transaction manager container images. |
| imagePullSecret.registryCredential.username | string | `"username"` | Private container registry username for pulling transaction manager container images. |
| ingress.annotations | object | `{"kubernetes.io/ingress.class":"nginx","nginx.ingress.kubernetes.io/backend-protocol":"HTTPS","nginx.ingress.kubernetes.io/client-body-buffer-size":"5m","nginx.ingress.kubernetes.io/proxy-body-size":"10m","nginx.ingress.kubernetes.io/proxy-read-timeout":"120","nginx.ingress.kubernetes.io/proxy-send-timeout":"120","nginx.ingress.kubernetes.io/ssl-passthrough":"true"}` | Ingress annotations. |
| ingress.className | string | `""` | Ingress class name. |
| ingress.enabled | bool | `false` | Create ingress or not. |
| ingress.host | string | `"tm.example.com"` | FQDN of a network host. |
| ingress.path | string | `"/tm"` | Path of an incoming request. |
| ingress.pathType | string | `"Prefix"` | Type of the interpretation of the Path matching. |
| ingress.tls.secret | string | `"ingress-tls"` | Name of th secret used to terminate TLS traffic. |
| javaOpts | string | `"-Xms4g -Xmx4g -XX:-OmitStackTraceInFastThrow"` | Java options passed to Transaction manager. |
| logLevel.hazelcast | string | `"INFO"` | Hazelcast log level. |
| logLevel.manager | string | `"INFO"` | Transaction manager application log level. |
| otelagent.enabled | bool | `false` | Enable OpenTelemetry or not. |
| otelagent.options | string | `""` | JVM options for OpenTelemetry. |
| service.annotations | object | `{}` | Service annotations. |
| service.loadBalancerSourceRanges | list | `[]` | IP address range for connection source when type is LoadBalancer. |
| service.txnmgrNodePort | int | `32002` | The port on each node on which Transaction manager service is exposed when type is NodePort. |
| service.type | string | `"ClusterIP"` | Service type. (ClusterIP, NodePort, and LoadBalancer) |
| txnmgr.azure.blobStorage | object | `{"containerName":"jobpayload","endpoint":"https://txnmgr.blob.core.windows.net/","sasToken":null}` | Azure Blob Storage configuration. |
| txnmgr.cacheReloadIntervalSecs | int | `60` | The interval in seconds to update the internal cache. |
| txnmgr.db.jdbcUrl | string | `"jdbc:mariadb://mysql.example.com:3306/txnmgr?serverTimezone=UTC&allowPublicKeyRetrieval=true&socketTimeout=3000"` | JDBC url to access paro database. Examples:   MySQL: jdbc:mariadb://mysql.example.com:3306/txnmgr?serverTimezone=UTC&sslMode=trust&allowPublicKeyRetrieval=true&socketTimeout=3000   Microsoft SQL Server: jdbc:sqlserver://mssql.example.com:1433;databaseName=txnmgr;encrypt=true;trustServerCertificate=true;socketTimeout=3000   PostgreSQL: jdbc:postgresql://postgresql.example.com:5432/txnmgr?ssl=true&sslmode=require   Oracle: jdbc:oracle:thin:@tcps://<endpoint>:2484/txnmgr?ssl_server_dn_match=false&wallet_location=/etc/wallets |
| txnmgr.db.oracleCWalletPath | string | `""` | Oracle Wallet auto login file paths. Required if using the Oracle database. |
| txnmgr.db.oracleEWalletPath | string | `""` | Oracle Wallet PKCS#12 file paths. Required if using the Oracle database. |
| txnmgr.db.password | string | `"password"` | Password to access database. |
| txnmgr.db.poolConnectionTimeout | string | `"30000"` | Maximum time to wait to create a new connection. |
| txnmgr.db.poolIdleTimeout | string | `"60000"` | Maximum amount of time that a connection is allowed to sit idle in the pool. |
| txnmgr.db.poolInitialSize | int | `10` | Initial connection pool size. |
| txnmgr.db.poolMaxSize | int | `100` | Maximal connection pool size. |
| txnmgr.db.profile | string | `"mssql"` | Database engine profile. (MySQL: `mysql`, Microsoft SQL Server: `mssql`, PostgreSQL: `postgresql`, Oracle: `oracle`) |
| txnmgr.db.username | string | `"username"` | Username to access database. |
| txnmgr.defaultParoUrl | string | `"https://paro-manager.paro.svc.cluster.local:8080/paro/v1"` | Default paro manager url. |
| txnmgr.extraEnvs | list | `[]` | Environment variables to be added to transaction manager. Only add environment variables that are not supported by this chart. |
| txnmgr.jp | object | `{"acquireTimeoutMilli":90000,"blobStorageType":"Db","checkLivenessJobConcurrency":10,"checkLivenessTimeoutMilli":60000,"convertJobConcurrency":10,"convertTimeoutMilli":60000,"datasetJobConcurrency":10,"extractJobConcurrency":10,"extractTimeoutMilli":60000,"iadExtractJobConcurrency":10,"iadExtractTimeoutMilli":60000,"inactiveTenantRetentionDays":15,"jobCallbackProcessChannelCapacity":50,"jobCallbackProcessConcurrency":20,"jobQueueDispatchChannelCapacity":20,"jobQueuePollIntervalMilli":5000,"jobQueueProcessConcurrency":10,"jobRetentionPeriodMinutes":30,"jobTimeoutPollIntervalMilli":5000,"jobWipPollIntervalMilli":5000,"jobWipProcessChannelCapacity":20,"jobWipProcessConcurrency":10,"prefixTenantIdInSearchResponse":false,"queueAcquireLimit":50,"searchTimeoutMilli":60000,"verifyJobConcurrency":10,"verifyTimeoutMilli":60000,"wipAcquireLimit":50}` | Job Processor configuration. |
| txnmgr.jp.acquireTimeoutMilli | int | `90000` | Timeout in milliseconds for acquiring jobs from the queue and wip. |
| txnmgr.jp.checkLivenessJobConcurrency | int | `10` | The maximum number of check liveness jobs. |
| txnmgr.jp.checkLivenessTimeoutMilli | int | `60000` | Timeout in milliseconds for liveness jobs. |
| txnmgr.jp.convertJobConcurrency | int | `10` | The maximum number of convert jobs that can be done concurrently. |
| txnmgr.jp.convertTimeoutMilli | int | `60000` | Timeout in milliseconds for convert jobs. |
| txnmgr.jp.datasetJobConcurrency | int | `10` | The maximum number of jobs that can be searched in dataset concurrently. |
| txnmgr.jp.extractJobConcurrency | int | `10` | The maximum number of jobs that can be extracted concurrently. |
| txnmgr.jp.extractTimeoutMilli | int | `60000` | Timeout in milliseconds for extraction jobs. |
| txnmgr.jp.iadExtractJobConcurrency | int | `10` | The maximum number of iad extract jobs. |
| txnmgr.jp.iadExtractTimeoutMilli | int | `60000` | Timeout in milliseconds for IAD extract jobs. |
| txnmgr.jp.jobQueuePollIntervalMilli | int | `5000` | The interval in milliseconds at which the job queue is polled for new jobs. |
| txnmgr.jp.jobRetentionPeriodMinutes | int | `30` | The period in minutes after which jobs are considered old and can be purged. |
| txnmgr.jp.jobTimeoutPollIntervalMilli | int | `5000` | The interval in milliseconds at which the job timeout is checked. |
| txnmgr.jp.jobWipPollIntervalMilli | int | `5000` | The interval in milliseconds at which the work-in-progress (WIP) jobs are polled. |
| txnmgr.jp.prefixTenantIdInSearchResponse | bool | `false` | Prefix tenantId to bin/dataset IDs in search responses (e.g., "tenantId/containerId"). |
| txnmgr.jp.queueAcquireLimit | int | `50` | Maximum number of jobs that can be acquired from the queue at once. |
| txnmgr.jp.searchTimeoutMilli | int | `60000` | Timeout in milliseconds for searching jobs. |
| txnmgr.jp.verifyJobConcurrency | int | `10` | The maximum number of jobs that can be verified concurrently. |
| txnmgr.jp.verifyTimeoutMilli | int | `60000` | Timeout in milliseconds for verification jobs. |
| txnmgr.jp.wipAcquireLimit | int | `50` | Maximum number of work-in-progress (WIP) jobs that can be acquired at once. |
| txnmgr.livenessProbe | object | `{"failureThreshold":3,"httpGet":{"path":"/tm/v1/info","port":8080,"scheme":"HTTPS"},"initialDelaySeconds":15,"periodSeconds":10,"successThreshold":1,"timeoutSeconds":3}` | Transaction manager container liveness probe. |
| txnmgr.maxStringSizeMB | int | `80` | Maximum JSON string size in MB allowed for request parsing. |
| txnmgr.ndpCacheServerServiceDns | string | `"ndp-cache-server.ndp-cache-server.svc.cluster.local"` | Kubernetes service DNS of NDP Cache Server (Hazelcast cluster). Ref: https://docs.hazelcast.com/hazelcast/latest/deploy/configuring-kubernetes#using-kubernetes-in-dns-lookup-mode |
| txnmgr.nodeSelector | object | `{"kubernetes.io/os":"linux"}` | Node label for Transaction manager pod assignment. |
| txnmgr.readinessProbe | object | `{"failureThreshold":3,"httpGet":{"path":"/tm/v1/info","port":8080,"scheme":"HTTPS"},"initialDelaySeconds":30,"periodSeconds":10,"successThreshold":1,"timeoutSeconds":3}` | Transaction manager container readiness probe. |
| txnmgr.replicas | int | `1` | Number of pods in transaction manager. |
| txnmgr.resources | object | `{"requests":{"cpu":"4000m","memory":"5000Mi"}}` | Transaction manager container resource requests and limits. |
| txnmgr.restClient | object | `{"connectTimeoutMilli":5000,"requestTimeoutMilli":30000,"socketTimeoutMilli":30000,"sslHandshakeTimeoutMilli":10000}` | Outbound HTTP client (Ktor) timeouts. Bound to prevent worker threads from being blocked by black-holed peers for the OS TCP timeout (~75-130s). |
| txnmgr.restClient.connectTimeoutMilli | int | `5000` | Maximum time in milliseconds to establish a TCP connection. |
| txnmgr.restClient.requestTimeoutMilli | int | `30000` | Maximum time in milliseconds for a complete HTTP request (connect + send + receive). |
| txnmgr.restClient.socketTimeoutMilli | int | `30000` | Maximum idle time in milliseconds between TCP packets on an established connection. |
| txnmgr.restClient.sslHandshakeTimeoutMilli | int | `10000` | Maximum time in milliseconds for the TLS handshake to complete. Surfaced as the JVM property `jdk.tls.handshakeTimeout`. |
| txnmgr.security | object | `{"requireSsl":true}` | Enable https for txnmgr |
| txnmgr.springdoc.pathsToExclude | string | `"none"` | Comma-separated list of paths to exclude from OpenAPI documentation. |
| txnmgr.startupProbe | object | `{"exec":{"command":["/bin/sh","-c","ps -ef \| grep java \| grep -v grep"]},"failureThreshold":6,"initialDelaySeconds":15,"periodSeconds":10,"successThreshold":1,"timeoutSeconds":3}` | Transaction manager container startup probe. |
| txnmgr.tolerations | list | `[]` | Tolerations for Transaction manager pod assignment. |
| txnmgrLiquibase.resources | object | `{"requests":{"cpu":"100m","memory":"200Mi"}}` | Transaction manager liquibase container resource requests and limits. |
| txnmgrsslsecret | string | `"txnmgr-ssl-secret"` |  |

