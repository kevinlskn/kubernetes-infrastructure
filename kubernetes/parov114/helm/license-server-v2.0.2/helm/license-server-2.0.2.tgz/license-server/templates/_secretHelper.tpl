{{- define "imagePullSecret" }}
{{- printf "{\"auths\": {\"%s\": {\"auth\": \"%s\"}}}" .Values.image.registry (printf "%s:%s" .Values.imagePullSecret.registryCredential.username .Values.imagePullSecret.registryCredential.password | b64enc) | b64enc }}
{{- end }}
